import pygame
from rettangolo import Rettangolo

pygame.init()

window_size = (800, 600)
window = pygame.display.set_mode(window_size)
pygame.display.set_caption("Rettangolini")

r_colore_base = (100, 100, 100)
r_colore_hover = (150, 150, 150)
r_colore_cliccato = (150, 150, 150)
rettangoli = []
rettangoli.append(Rettangolo(window, 100, 100, 200, 100, r_colore_base, r_colore_hover, r_colore_cliccato))
rettangoli.append(Rettangolo(window, 350, 100, 100, 100, r_colore_base, r_colore_hover, r_colore_cliccato))

while True:

    # inputs
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                exit()


        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            for rettangolo in rettangoli:
                if rettangolo.rect.collidepoint(pos):
                    rettangolo.click()
            

    pos = pygame.mouse.get_pos()
    for rettangolo in rettangoli:
        if rettangolo.rect.collidepoint(pos):
            rettangolo.hover = True
        else:
            rettangolo.hover = False

    for rettangolo in rettangoli:
        rettangolo.draw()    

    pygame.display.update()
