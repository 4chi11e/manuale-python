import pygame

class Rettangolo:
    def __init__(self, window, x, y, width, height, colore_base, colore_hover, colore_cliccato):
        self.window = window
        
        self.image = pygame.Surface((width, height))
        self.image.fill(colore_base)
        # self.rect = self.image.get_rect(topleft=(x, y))
        self.rect = pygame.Rect(x, y, width, height)

        self.colore_base = colore_base
        self.colore_hover = colore_hover
        self.colore_cliccato = colore_cliccato

        self.cliccato = False
        self.hover = False

    def draw(self):
        if self.cliccato:
            self.image.fill(self.colore_cliccato)
        elif self.hover:
            self.image.fill(self.colore_hover)
        else:
            self.image.fill(self.colore_base)

        self.window.blit(self.image, self.rect)

    def click(self):
        if self.cliccato:
            self.cliccato = False
        else:
            self.cliccato = True
    