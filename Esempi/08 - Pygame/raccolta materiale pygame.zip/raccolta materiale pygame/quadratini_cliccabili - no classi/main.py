import pygame

pygame.init()

window_size = (800, 600)
window = pygame.display.set_mode(window_size)
pygame.display.set_caption("Rettangolini")

r_colore_base = (100, 100, 100)
r_colore_hover = (150, 150, 150)
r_colore_cliccato = (150, 150, 150)
r_cliccato = False
r = pygame.draw.rect(window, r_colore_base, (100, 100, 100, 100))
print(r)



while True:

    # inputs
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                exit()


        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            if r.collidepoint(pos):
                # print("cliccato")
                if r_cliccato == False:
                    r_cliccato = True
                    r = pygame.draw.rect(window, r_colore_cliccato, r)
                else:
                    r_cliccato = False
                    r = pygame.draw.rect(window, r_colore_base, r)
            

    pos = pygame.mouse.get_pos()
    if r.collidepoint(pos):
        r = pygame.draw.rect(window, r_colore_hover, r)
    else:
        if r_cliccato:
            r = pygame.draw.rect(window, r_colore_cliccato, r)
        else:
            r = pygame.draw.rect(window, r_colore_base, r)

    pygame.display.update()
