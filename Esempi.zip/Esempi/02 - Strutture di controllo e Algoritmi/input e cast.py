x = input("Scrivi un numero:")
print(x, type(x))

x = int(input("Scrivi un numero:"))
print(x, type(x))
x = str(x)
print(x, type(x))
x = int(x)
print(x, type(x))