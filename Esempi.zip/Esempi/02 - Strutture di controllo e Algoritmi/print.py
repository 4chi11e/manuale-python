import math


print("ciao")
print("ciao","bello!", "Oggi è il", 5, "Ottobre")


g = 5
m = "Ottobre"
a = 2022
print(f"Oggi è il {g} {m} {a}")


p = math.pi
print(f"Pi greco con ingombro 7 e 3 decimali {p:7.3f}")