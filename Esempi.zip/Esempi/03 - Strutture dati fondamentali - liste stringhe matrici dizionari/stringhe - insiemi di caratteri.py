# qui trovi informazioni sulla libreria string: https://docs.python.org/3/library/string.html

import string

lettere = string.ascii_letters
print(lettere)

minuscole = string.ascii_lowercase
print(minuscole)

maiuscole = string.ascii_uppercase
print(maiuscole)

# sul link sopra trovi altri insiemi