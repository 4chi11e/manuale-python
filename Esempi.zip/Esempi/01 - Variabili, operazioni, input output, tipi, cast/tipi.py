import os
os.system("cls")


print(5, type(5))
print("5", type("5"))
print("int('5')", type(int('5')))
print("A", type("A"))
print(5.23, type(5.23))
print(False, type(False))

lista = ['casa', 5, 7.2]
print(lista, type(lista))

dizionario = {"Francesco": 36, "Paolo": 42, "Emanuele": 44}
print(dizionario, type(dizionario))

insieme = {"lunedì", "martedì", "mercoledì"}
print(insieme, type(insieme))

print(range(10), type(range(10)))


